---
name: stride-threat-model
description: Threat modeling skill for safe agentic coding.
---

# STRIDE Threat Model Skill

Check for spoofing, tampering, repudiation, information disclosure, denial of service, and elevation of privilege.
